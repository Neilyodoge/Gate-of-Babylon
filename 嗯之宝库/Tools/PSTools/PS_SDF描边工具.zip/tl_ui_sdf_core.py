"""Standard-library pixel worker for TL_UI_SDF_Baker.jsx (Python 3)."""
import json
import math
from array import array
from pathlib import Path
import struct
import sys

MAX_PIXELS = 4194304
INF = 1e20


def write_json(path, value):
    temporary = Path(str(path) + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=True), encoding='ascii')
    temporary.replace(path)


def write_progress(path, value):
    # Windows can deny replace while Photoshop has the previous snapshot open.
    # Progress is advisory: keep the old snapshot and publish the next update.
    # Result metadata and image output still use strict writes.
    try:
        write_json(path, value)
        return True
    except PermissionError:
        return False


def read_tga(path):
    data = Path(path).read_bytes()
    if len(data) < 18 or data[1] != 0 or data[2] != 2 or data[16] != 32:
        raise ValueError('Expected uncompressed 32-bit RGB TGA from Photoshop.')
    width, height = struct.unpack_from('<HH', data, 12)
    if not width or not height or width * height > MAX_PIXELS:
        raise ValueError('Image is empty or exceeds 4,194,304 pixels.')
    start = 18 + data[0]
    pixels = data[start:start + width * height * 4]
    if len(pixels) != width * height * 4:
        raise ValueError('Incomplete TGA pixel data.')
    if not data[17] & 32:
        pixels = b''.join(pixels[y * width * 4:(y + 1) * width * 4]
                          for y in range(height - 1, -1, -1))
    if data[17] & 16:
        pixels = b''.join(pixels[(y * width + x) * 4:(y * width + x + 1) * 4]
                          for y in range(height) for x in range(width - 1, -1, -1))
    return width, height, pixels


def transform_1d(values):
    length = len(values)
    vertices = [0] * length
    boundaries = [float('-inf')] + [float('inf')] * length
    k = 0
    for q in range(1, length):
        while True:
            p = vertices[k]
            intersection = ((values[q] + q * q) - (values[p] + p * p)) / (2 * (q - p))
            if intersection > boundaries[k]:
                break
            k -= 1
        k += 1
        vertices[k] = q
        boundaries[k] = intersection
        boundaries[k + 1] = float('inf')
    distances = [0.0] * length
    nearest = [0] * length
    k = 0
    for q in range(length):
        while boundaries[k + 1] < q:
            k += 1
        p = vertices[k]
        distances[q] = (q - p) ** 2 + values[p]
        nearest[q] = p
    return distances, nearest


def squared_distances(width, height, inside, progress):
    distances = array('d', [0.0]) * (width * height)
    for x in range(width):
        column = [0 if inside[y * width + x] else INF
                  for y in range(height)]
        output, _ = transform_1d(column)
        for y in range(height):
            distances[y * width + x] = output[y]
        if x % 32 == 0:
            progress(0.5 * x / width)
    for y in range(height):
        offset = y * width
        output, _ = transform_1d(distances[offset:offset + width])
        for x in range(width):
            distances[offset + x] = output[x]
        if y % 32 == 0:
            progress(0.5 + 0.5 * y / height)
    progress(1)
    return distances


def bake_pixels(width, height, pixels, distance_range=16, threshold=128,
                dilate_rgb=False, progress=lambda value: None):
    # The old dilate_rgb argument remains accepted; RGB is copied byte-for-byte.
    if not 1 <= distance_range <= 64 or threshold != 128:
        raise ValueError('Range must be 1..64; binary Alpha threshold is fixed at 128 (0.5).')
    count = width * height
    if not 0 < count <= MAX_PIXELS or len(pixels) != count * 4:
        raise ValueError('Invalid image dimensions or pixel data.')
    alphas = pixels[3::4]
    inside = bytes(a >= 128 for a in alphas)
    inside_count = sum(inside)
    if not inside_count:
        raise ValueError('No subject pixels above Alpha 0.5.')
    fractional_count = sum(0 < a < 255 for a in alphas)
    touches_edge = any(inside[:width]) or any(inside[-width:]) or any(
        inside[y * width] or inside[(y + 1) * width - 1] for y in range(height))
    progress(0.05)
    # One EDT only: distance to the binary body. No interior distance is stored.
    distances = squared_distances(width, height, inside,
                                  lambda f: progress(0.05 + 0.75 * f))
    baked = bytearray(pixels)
    for i in range(count):
        if inside[i]:
            baked[i * 4 + 3] = 255
        else:
            distance = math.sqrt(max(0, distances[i]))
            baked[i * 4 + 3] = max(0, min(254, math.floor(
                255 * max(0, 1 - distance / distance_range) + 0.5)))
        if i % 16384 == 0:
            progress(0.8 + 0.2 * i / count)
    progress(1)
    return bytes(baked), {
        'width': width, 'height': height, 'range': distance_range,
        'threshold': 128, 'insideCount': inside_count,
        'fractionalCount': fractional_count, 'touchesEdge': bool(touches_edge),
        'encoding': 'TL_UI_SDF_OUTSIDE_V3',
    }


def main():
    source, output, result_path, progress_path, cancel_path, distance_range, threshold, dilate = sys.argv[1:]
    try:
        def progress(fraction):
            if Path(cancel_path).exists():
                raise RuntimeError('Bake cancelled.')
            write_progress(Path(progress_path), {'fraction': fraction})
        width, height, pixels = read_tga(source)
        baked, metadata = bake_pixels(width, height, pixels, int(distance_range),
                                      int(threshold), dilate == '1', progress)
        header = bytearray(18)
        header[2] = 2
        struct.pack_into('<HH', header, 12, width, height)
        header[16:18] = bytes([32, 40])
        temporary = Path(output + '.tmp')
        temporary.write_bytes(header + baked)
        temporary.replace(output)
        write_json(Path(result_path), {'ok': True, 'metadata': metadata})
        return 0
    except Exception as error:
        write_json(Path(result_path), {'ok': False, 'error': str(error)})
        return 1


if __name__ == '__main__':
    sys.exit(main())
